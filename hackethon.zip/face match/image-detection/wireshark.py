from scapy.all import sniff

# Define a callback function to handle captured packets
def packet_callback(packet):
    print(packet.summary())

# Sniff packets and invoke callback for each packet captured
sniff(prn=packet_callback, store=0)
