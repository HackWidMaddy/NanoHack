import cv2
import numpy as np
import sqlite3
import pyautogui
import time
import tkinter as tk

# Load the pre-trained cascade classifier for face detection
faceCascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# Load the pre-trained LBPH face recognizer
recognizer = cv2.face.LBPHFaceRecognizer_create()
recognizer.read("image-detection/recognizer/trainningData.yml")

# Function to retrieve profile from the database based on ID
def getProfile(id):
    conn = sqlite3.connect("image-detection/FaceBase.db")
    cursor = conn.execute("SELECT * FROM People WHERE ID=?", (id,))
    profile = cursor.fetchone()
    conn.close()
    return profile

# Font properties for displaying text on the screen
fontFace = cv2.FONT_HERSHEY_SIMPLEX
fontScale = 1
fontColor = (0, 255, 0)
people_detected = []
popup_shown = False

# Function to show pop-up for name and GPS coordinates
def show_popup(name):
    popup = tk.Tk()
    popup.title("Intrusion Detected")
    
    tk.Label(popup, text="Intrusion Detected", font=("Helvetica", 16)).pack(pady=10)
    tk.Label(popup, text=f"Name: {name}", font=("Helvetica", 12)).pack()
    
    popup.mainloop()

while True:
    time.sleep(1)
    # Capture the screen
    img = pyautogui.screenshot()
    frame = np.array(img)

    # Convert the image to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Detect faces in the grayscale image
    faces = faceCascade.detectMultiScale(gray, 1.3, 5)

    # Iterate through detected faces
    for (x, y, w, h) in faces:
        # Draw rectangle around the face
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)

        # Recognize the face
        id, conf = recognizer.predict(gray[y:y+h, x:x+w])

        # Get profile information from database
        profile = getProfile(id)

        # Display profile information if available
        if profile:
            if str(profile[1]) in people_detected:
                pass
            else:
                cv2.putText(frame, "Name: " + str(profile[1]), (x, y+h+20), fontFace, fontScale, fontColor)
                cv2.putText(frame, "Age: " + str(profile[2]), (x, y+h+45), fontFace, fontScale, fontColor)
                cv2.putText(frame, "Gender: " + str(profile[3]), (x, y+h+70), fontFace, fontScale, fontColor)
                cv2.putText(frame, "Criminal Records: " + str(profile[4]), (x, y+h+95), fontFace, fontScale, fontColor)
                print(str(profile[1]))

                if not popup_shown:
                    show_popup(str(profile[1]))
                    popup_shown = True

                people_detected.append(str(profile[1]))
    # Display the frame
    cv2.imshow("Face Detection", frame)

    # Break the loop if 'q' is pressed
    if cv2.waitKey(1) == ord('q'):
        break

# Release the camera and close all OpenCV windows
cv2.destroyAllWindows()
