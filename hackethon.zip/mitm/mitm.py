from scapy.all import *

def forward_packet(packet):
    # Check if the packet is incoming
    if packet.haslayer(IP):
        # Print original destination IP address
        original_dst = packet[IP].dst
        print("Original Destination IP:", original_dst)

        # Change the destination IP address to 172.17.29.100
        packet[IP].dst = '172.17.29.100'

        # Send the modified packet
        send(packet)

# Start sniffing packets and call forward_packet for each captured packet
sniff(prn=forward_packet, store=0, filter="inbound")