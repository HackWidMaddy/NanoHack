import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# Email and password
email = 'harshzaveri54@gmail.com'
password = 'iralcymdfqbsuvag'  # App secret or app password

# Recipient email
to_email = 'harshzaveri54@gmail.com'

# Message content
subject = 'Test Email'
body = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Intrusion Detected</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #333333;
        }
        p {
            color: #666666;
        }
        .button {
            display: inline-block;
            background-color: #4caf50;
            color: #ffffff;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
        }
        .button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Intrusion Detected</h1>
        <p>Dear User,</p>
        <p>We regret to inform you that an intrusion has been detected on your system. Please take immediate action to ensure the security of your data and system integrity.</p>
        <p>If you believe this is a false alarm, please disregard this message. Otherwise, take appropriate measures to mitigate the security breach.</p>
        <p>Thank you for your attention to this matter.</p>
        <p>Sincerely,<br>Your Security Team</p>
        <a href="#" class="button">Take Action</a>
    </div>
</body>
</html>

'''
# Setup the MIME
message = MIMEMultipart()
message['From'] = email
message['To'] = to_email
message['Subject'] = subject

# Attach the message body
message.attach(MIMEText(body, 'html'))  # Set content type to HTML

# Connect to Gmail's SMTP server
server = smtplib.SMTP('smtp.gmail.com', 587)
server.starttls()

# Login to your Gmail account
server.login(email, password)

# Send email
text = message.as_string()
server.sendmail(email, to_email, text)

# Close the connection
server.quit()

print('Email sent successfully!')
